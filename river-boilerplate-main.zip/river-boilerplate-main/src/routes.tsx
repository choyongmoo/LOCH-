import { BrowserRouter, Route, Routes as RouterRoutes } from "react-router";
import { AuthLayout } from "./layouts/AuthLayout";
import { MainLayout } from "./layouts/MainLayout";
import { WorkspaceLayout } from "./layouts/WorkspaceLayout";
import { Login } from "./pages/Auth/Login";
import { Register } from "./pages/Auth/Register";
import { Home } from "./pages/Home";
import { Support } from "./pages/Home/Support";
import { NotFound } from "./pages/NotFound";
import { Workspace } from "./pages/Workspace";

export const Routes = () => {
  return (
    <BrowserRouter>
      <RouterRoutes>
        <Route path="/">
          <Route element={<MainLayout />}>
            <Route index element={<Home />} />
            <Route path="support" element={<Support />} />
          </Route>

          <Route element={<AuthLayout />}>
            <Route path="login" element={<Login />} />
            <Route path="register" element={<Register />} />
          </Route>
        </Route>

        <Route path="/workspace" element={<WorkspaceLayout />}>
          <Route index element={<Workspace />} />
        </Route>

        <Route path="*" element={<NotFound />} />
      </RouterRoutes>
    </BrowserRouter>
  );
};
