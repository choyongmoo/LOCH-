import { Outlet } from "react-router";
import { Sidebar } from "../components/Workspace/Sidebar";

export const WorkspaceLayout = () => {
  return (
    <div>
      <Sidebar />
      <Outlet />
    </div>
  );
};
