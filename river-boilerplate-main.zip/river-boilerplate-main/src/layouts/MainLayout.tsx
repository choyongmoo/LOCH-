import { Outlet } from "react-router";
import { Footer } from "../components/Home/Footer";
import { Header } from "../components/Home/Header";
import { Navbar } from "../components/Home/Navbar";

export const MainLayout = () => {
  return (
    <div className="flex-col">
      <div className="fixed top-0 w-full z-50 pointer-events-none">
        <Header />
      </div>
      <div className="flex flex-col items-center">
        <div className="p-8 relative z-10">
          <Navbar />
        </div>
        <div className="w-6xl">
          <Outlet />
        </div>
      </div>
      <div className="w-full">
        <Footer />
      </div>
    </div>
  );
};
