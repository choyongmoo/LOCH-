import { Button } from "@/components/common/ui/button";
import { Link } from "react-router";

export const Home = () => {
  return (
    <main className="">
      {/* Hero Section */}
      <section className="bg-gray-100 text-center py-20 rounded-lg">
        <h1 className="text-5xl font-bold">Welcome to River</h1>
        <p className="text-xl mt-4">
          A boilerplate for your next React project.
        </p>
        <Button asChild className="mt-8">
          <Link to="/register">Get Started</Link>
        </Button>
      </section>

      {/* Features Section */}
      <section className="container mx-auto py-20">
        <h2 className="text-4xl font-bold text-center">Features</h2>
        <div className="grid md:grid-cols-2 gap-8 mt-10">
          <div className="flex flex-col items-center text-center">
            <img
              src="/placeholder_cat.jpg"
              alt="Feature 1"
              className="w-full h-64 object-cover rounded-lg"
            />
            <h3 className="text-2xl font-bold mt-4">Feature One</h3>
            <p className="mt-2">
              Discover the amazing features we have to offer.
            </p>
          </div>
          <div className="flex flex-col items-center text-center">
            <img
              src="/placeholder_fox.jpg"
              alt="Feature 2"
              className="w-full h-64 object-cover rounded-lg"
            />
            <h3 className="text-2xl font-bold mt-4">Feature Two</h3>
            <p className="mt-2">
              Our platform is designed to be intuitive and easy to use.
            </p>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-primary text-white text-center py-20 rounded-lg mb-20">
        <h2 className="text-4xl font-bold">Ready to dive in?</h2>
        <p className="text-xl mt-4">
          Create an account and start exploring today.
        </p>
        <Button asChild variant="secondary" className="mt-8">
          <Link to="/register">Sign Up Now</Link>
        </Button>
      </section>
    </main>
  );
};
