import { Link } from "react-router";
import logo from "../../assets/react.svg";
import { Button } from "../common/ui/button";

export const Header = () => {
  return (
    <header className="flex items-center justify-between p-8">
      <div className="flex items-center pointer-events-auto">
        <img src={logo} alt="logo" className="w-9 h-9" />
        <h1 className="text-3xl font-bold pl-2">React</h1>
      </div>
      <div className="pointer-events-auto">
        <Button asChild>
          <Link to="/login">
            <span className="text-base font-bold">Log In</span>
          </Link>
        </Button>
      </div>
    </header>
  );
};
